import React from "react";
import "./style.css";

export const Frame = () => {
  return (
    <div className="frame">
      <div className="div">
        <div className="group-wrapper">
          <div className="group">
            <div className="div-2">
              <div className="overlap">
                <div className="text-wrapper">Logo</div>
              </div>
              <div className="overlap-group">
                <div className="text-wrapper-2">forgot my password</div>
                <div className="text-wrapper-3">Login</div>
                <p className="p">sign in to your account</p>
                <div className="div-wrapper">
                  <div className="text-wrapper-4">Register new account</div>
                </div>
                <div className="overlap-2">
                  <div className="text-wrapper-5">Login</div>
                </div>
                <div className="overlap-3">
                  <div className="text-wrapper-6">Username</div>
                  <div className="rectangle" />
                  <img className="img" alt="Vector" src="/img/vector-5.svg" />
                </div>
                <div className="overlap-4">
                  <div className="text-wrapper-7">Password</div>
                  <img className="img" alt="Key solid" src="/img/key-solid-1.svg" />
                  <div className="rectangle" />
                  <img className="vector" alt="Vector" src="/img/vector-8.svg" />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="group-wrapper-2">
          <div className="group">
            <div className="div-2">
              <div className="overlap">
                <div className="text-wrapper-8">Logo</div>
              </div>
              <div className="overlap-5">
                <div className="overlap-6">
                  <div className="text-wrapper-9">already have an account</div>
                  <div className="group-2">
                    <div className="overlap-group-wrapper">
                      <div className="overlap-group-2">
                        <div className="text-wrapper-10">Confirm the password</div>
                        <img className="key-solid" alt="Key solid" src="/img/key-solid-1-2.svg" />
                        <div className="rectangle-2" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="text-wrapper-11">Create An Account</div>
                <div className="group-3">
                  <div className="overlap-group-3">
                    <div className="text-wrapper-12">Create an account</div>
                  </div>
                </div>
                <div className="overlap-7">
                  <div className="text-wrapper-6">Create an Username</div>
                  <div className="rectangle" />
                  <img className="vector-2" alt="Vector" src="/img/vector-5.svg" />
                </div>
                <div className="overlap-wrapper">
                  <div className="overlap-group-2">
                    <div className="text-wrapper-13">Create an Password</div>
                    <img className="key-solid" alt="Key solid" src="/img/key-solid-1-3.svg" />
                    <div className="rectangle-2" />
                    <img className="vector-3" alt="Vector" src="/img/vector-4.svg" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="div-3">
          <div className="overlap">
            <div className="text-wrapper-8">Logo</div>
          </div>
          <div className="overlap-5">
            <div className="text-wrapper-11">Create An Account</div>
            <div className="group-3">
              <div className="overlap-group-3">
                <div className="text-wrapper-12">Create an account</div>
              </div>
            </div>
            <div className="overlap-8">
              <div className="rectangle-3" />
              <div className="text-wrapper-6">Create an Username</div>
              <img className="vector-2" alt="Vector" src="/img/vector-5.svg" />
              <div className="group-4">
                <div className="group-5">
                  <div className="overlap-group-4">
                    <div className="text-wrapper-13">Create an Password</div>
                    <img className="key-solid" alt="Key solid" src="/img/key-solid-1-1.svg" />
                    <div className="rectangle-2" />
                    <img className="vector-3" alt="Vector" src="/img/vector-4.svg" />
                  </div>
                  <div className="rectangle-4" />
                </div>
              </div>
              <div className="rectangle" />
            </div>
            <div className="overlap-9">
              <div className="group-2">
                <div className="overlap-group-wrapper">
                  <div className="overlap-group-2">
                    <div className="rectangle-5" />
                    <div className="text-wrapper-14">Password doesn’t match</div>
                  </div>
                </div>
              </div>
              <img className="key-solid-2" alt="Key solid" src="/img/key-solid-2.svg" />
            </div>
          </div>
        </div>
        <div className="div-4">
          <div className="text-wrapper-15">RuiKang Leng</div>
          <div className="overlap">
            <div className="text-wrapper-16">Groups</div>
            <div className="text-wrapper-17">Topics</div>
            <div className="text-wrapper-18">Logo</div>
          </div>
          <div className="ellipse" />
          <div className="overlap-10">
            <div className="text-wrapper-19">role</div>
          </div>
          <div className="rectangle-6" />
          <div className="rectangle-7" />
          <div className="overlap-11">
            <div className="text-wrapper-20">email address</div>
          </div>
        </div>
        <div className="overlap-12">
          <div className="div-5">
            <img className="circle-user-solid" alt="Circle user solid" src="/img/circle-user-solid-1.svg" />
            <img className="vector-4" alt="Vector" src="/img/vector-3.svg" />
            <img className="user-group-solid" alt="User group solid" src="/img/user-group-solid-1.svg" />
            <div className="overlap-13">
              <div className="text-wrapper-21">Topics</div>
              <div className="overlap-group-5">
                <div className="rectangle-8" />
                <div className="text-wrapper-22">Search</div>
                <img className="vector-5" alt="Vector" src="/img/vector-1.svg" />
              </div>
              <div className="rectangle-9" />
              <div className="rectangle-10" />
              <div className="rectangle-11" />
              <div className="rectangle-12" />
              <div className="rectangle-13" />
              <div className="rectangle-14" />
              <div className="rectangle-15" />
              <div className="rectangle-16" />
              <div className="rectangle-17" />
            </div>
            <img className="vector-6" alt="Vector" src="/img/vector-2.svg" />
            <div className="overlap-14">
              <div className="text-wrapper-23">Topic title</div>
            </div>
          </div>
          <div className="rectangle-18" />
        </div>
      </div>
    </div>
  );
};
